// ============================================================
// 設定：DISCORD_CLIENT_ID / DISCORD_GUILD_ID / MEMBER_ROLE_IDS
// 直接改這裡即可（不是機密資訊）
// ============================================================
const DISCORD_CLIENT_ID = '你的 Discord Application Client ID';
const DISCORD_GUILD_ID = '你的 Discord 伺服器（Guild）ID';
// 符合其中一個身分組即視為會員（換成你自己伺服器的身分組 ID）
const MEMBER_ROLE_IDS = [
  '你的會員身分組ID_1',
  '你的會員身分組ID_2',
  '你的會員身分組ID_3',
];

// 機密資訊改放「專案設定 → 指令碼屬性」，不要寫在程式碼裡：
//   DISCORD_CLIENT_SECRET
//   DISCORD_BOT_TOKEN   （只有每小時巡檢會用到）

const QUEUE_SHEET = 'Queue';
const MEMBERS_SHEET = 'Members';
const REFRESH_TOKENS_SHEET = 'RefreshTokens'; // 獨立存放每個會員的 refresh token
const ACCESS_NOERS_SHEET = 'access_noers'; // 無條件放行名單，不受 Discord 身分組驗證影響
const STATUS_SHEET = 'CurrentWhitelist'; // 由 poller.js 每次同步，這裡拿來當「目前白名單」的參考
// 人工審核通過、沒有身分組也永久放行的名單（管理員手動維護，A 欄填 Discord ID）
const DISCORD_OVERRIDE_SHEET = 'discord_override';
const SESSION_TTL_SECONDS = 21600; // session 有效 6 小時

// 登入時查身分組要用的 OAuth scope：
// - identify：拿使用者基本資料
// - guilds.members.read：讓我們可以用「使用者自己的權杖」查他在指定伺服器內的成員資料（含身分組）
//   這是刻意選的方式：改用使用者自己的權杖而不是 Bot Token，
//   避開 GAS 呼叫 Bot Token 版 API 時會被 Cloudflare 間歇性擋掉的問題
//   （回傳 {"message":"internal network error","code":40333}）
const OAUTH_SCOPES = 'identify guilds.members.read';

function getProp_(key) {
  return PropertiesService.getScriptProperties().getProperty(key);
}

function getRedirectUri_() {
  return ScriptApp.getService().getUrl();
}

// ------------------------------------------------------------
// 網頁進入點
// ------------------------------------------------------------
function doGet(e) {
  const code = e && e.parameter && e.parameter.code;
  if (code) {
    return handleCallback_(code);
  }
  return renderPage_({ stage: 'login' });
}

// 查這個 Discord ID 是不是在人工核准的永久放行名單裡
function isOverrideAllowed_(discordId) {
  const sheet = getSheet_(DISCORD_OVERRIDE_SHEET);
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(discordId)) return true;
  }
  return false;
}

function handleCallback_(code) {
  const tokenResp = exchangeCode_(code);
  if (!tokenResp || !tokenResp.access_token) {
    return renderPage_({ stage: 'error', message: 'Discord 授權失敗，請重新嘗試一次。' });
  }
  const user = getDiscordUser_(tokenResp.access_token);
  if (!user || !user.id) {
    return renderPage_({ stage: 'error', message: '無法取得 Discord 使用者資訊。' });
  }

  const hasRole = isOverrideAllowed_(user.id) || checkMemberRoleWithUserToken_(tokenResp.access_token);
  if (!hasRole) {
    return renderPage_({ stage: 'denied', username: user.username });
  }

  const sessionId = Utilities.getUuid();
  // 把 refresh_token 一起存進 session，等玩家送出 MC UUID 時一起寫進 Members 表，
  // 之後每小時巡檢才能用「這個會員自己的權杖」重新驗證，不用碰會被擋的 Bot Token
  CacheService.getScriptCache().put('session_' + sessionId, JSON.stringify({
    id: user.id,
    refreshToken: tokenResp.refresh_token || '',
  }), SESSION_TTL_SECONDS);
  return renderPage_({ stage: 'form', username: user.username, sessionId: sessionId });
}

function exchangeCode_(code) {
  const resp = UrlFetchApp.fetch('https://discord.com/api/oauth2/token', {
    method: 'post',
    payload: {
      client_id: DISCORD_CLIENT_ID,
      client_secret: getProp_('DISCORD_CLIENT_SECRET'),
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: getRedirectUri_(),
    },
    muteHttpExceptions: true,
  });
  return JSON.parse(resp.getContentText());
}

function getDiscordUser_(accessToken) {
  const resp = UrlFetchApp.fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: 'Bearer ' + accessToken },
    muteHttpExceptions: true,
  });
  return JSON.parse(resp.getContentText());
}

// 用「使用者自己的權杖」查他在指定伺服器內的身分組（不是用 Bot Token）
function checkMemberRoleWithUserToken_(userAccessToken) {
  const resp = UrlFetchApp.fetch(
    'https://discord.com/api/users/@me/guilds/' + DISCORD_GUILD_ID + '/member',
    {
      headers: { Authorization: 'Bearer ' + userAccessToken },
      muteHttpExceptions: true,
    }
  );
  const code = resp.getResponseCode();
  Logger.log('checkMemberRoleWithUserToken_ httpStatus=%s body=%s', code, resp.getContentText());
  if (code !== 200) return false; // 404 = 不在該伺服器內
  const member = JSON.parse(resp.getContentText());
  const roles = member.roles || [];
  return MEMBER_ROLE_IDS.some((id) => roles.indexOf(id) !== -1);
}

// 用某個會員的 refresh token 換一組目前有效的 access token
// 回傳 {accessToken, refreshToken}：Discord 可能會在換 token 時同時輪替 refresh_token，
// 所以要把新的 refresh_token 一起存回去，不然下次巡檢會失敗
function refreshUserAccessToken_(refreshToken) {
  if (!refreshToken) return null;
  const resp = UrlFetchApp.fetch('https://discord.com/api/oauth2/token', {
    method: 'post',
    payload: {
      client_id: DISCORD_CLIENT_ID,
      client_secret: getProp_('DISCORD_CLIENT_SECRET'),
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
    },
    muteHttpExceptions: true,
  });
  const data = JSON.parse(resp.getContentText());
  if (!data.access_token) return null;
  return {
    accessToken: data.access_token,
    // Discord 沒有回傳新的就沿用舊的，理論上不太會發生，但保險起見
    refreshToken: data.refresh_token || refreshToken,
  };
}

// 給每小時巡檢用：這裡沒有使用者當場的權杖，只能用 Bot Token 查
// （有機率被 Cloudflare 擋掉，但這是背景非緊急工作，偶爾漏掉下次還會再檢查一次）
function checkMemberRoleWithBotToken_(discordUserId) {
  const maxAttempts = 3;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const resp = UrlFetchApp.fetch(
      'https://discord.com/api/guilds/' + DISCORD_GUILD_ID + '/members/' + discordUserId,
      {
        headers: { Authorization: 'Bot ' + getProp_('DISCORD_BOT_TOKEN') },
        muteHttpExceptions: true,
      }
    );
    const code = resp.getResponseCode();
    const body = resp.getContentText();
    if (code === 200) {
      const member = JSON.parse(body);
      const roles = member.roles || [];
      return MEMBER_ROLE_IDS.some((id) => roles.indexOf(id) !== -1);
    }
    const isCloudflareBlock = body.indexOf('40333') !== -1;
    if (!isCloudflareBlock || attempt === maxAttempts) return false;
    Utilities.sleep(800);
  }
  return false;
}

// 用 Mojang API 把 UUID 轉換成目前的遊戲名稱
function resolveUuidToName_(uuid) {
  const resp = UrlFetchApp.fetch(
    'https://sessionserver.mojang.com/session/minecraft/profile/' + uuid,
    { muteHttpExceptions: true }
  );
  if (resp.getResponseCode() !== 200) return null; // 404 = 查無此 UUID
  const data = JSON.parse(resp.getContentText());
  return data.name || null;
}

function renderPage_(data) {
  const tpl = HtmlService.createTemplateFromFile('index');
  tpl.data = data;
  tpl.authUrl = 'https://discord.com/api/oauth2/authorize'
    + '?client_id=' + DISCORD_CLIENT_ID
    + '&redirect_uri=' + encodeURIComponent(getRedirectUri_())
    + '&response_type=code&scope=' + encodeURIComponent(OAUTH_SCOPES);
  return tpl.evaluate()
    .setTitle('白名單申請')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ------------------------------------------------------------
// 工作表輔助
// ------------------------------------------------------------
function getSheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (name === QUEUE_SHEET) {
      sheet.appendRow(['Timestamp', 'Action', 'Username', 'Status', 'ProcessedAt', 'Note']);
    } else if (name === MEMBERS_SHEET) {
      sheet.appendRow(['DiscordID', 'DiscordUsername', 'MCName', 'Status', 'JoinedAt', 'LastCheckedAt', 'MCUUID']);
    } else if (name === REFRESH_TOKENS_SHEET) {
      sheet.appendRow(['DiscordID', 'RefreshToken', 'UpdatedAt']);
    } else if (name === DISCORD_OVERRIDE_SHEET) {
      sheet.appendRow(['DiscordID', 'Note']);
    }
  }
  return sheet;
}

// ------------------------------------------------------------
// RefreshTokens 分頁輔助：獨立存放每個會員的 refresh token
// ------------------------------------------------------------
function getRefreshToken_(discordId) {
  const sheet = getSheet_(REFRESH_TOKENS_SHEET);
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(discordId)) return data[i][1] || '';
  }
  return '';
}

function setRefreshToken_(discordId, refreshToken) {
  if (!refreshToken) return;
  const sheet = getSheet_(REFRESH_TOKENS_SHEET);
  const data = sheet.getDataRange().getValues();
  const now = new Date();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(discordId)) {
      sheet.getRange(i + 1, 2).setValue(refreshToken);
      sheet.getRange(i + 1, 3).setValue(now);
      return;
    }
  }
  sheet.appendRow([discordId, refreshToken, now]);
}

// ------------------------------------------------------------
// 前端呼叫：驗證通過後提交 MC UUID（後端翻譯成目前的使用者名稱）
// ------------------------------------------------------------
function submitMcUuid(sessionId, mcUuidInput) {
  const sessionRaw = CacheService.getScriptCache().get('session_' + sessionId);
  if (!sessionRaw) {
    throw new Error('驗證已過期，請重新用 Discord 登入一次');
  }
  const session = JSON.parse(sessionRaw);
  const discordId = session.id;
  const refreshToken = session.refreshToken || '';

  const raw = String(mcUuidInput || '').trim();
  if (!/^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$/.test(raw)) {
    throw new Error('UUID 格式錯誤，請確認貼上完整的 32 碼 UUID（有無 - 都可以）');
  }
  const uuid = raw.replace(/-/g, '').toLowerCase();

  const mcName = resolveUuidToName_(uuid);
  if (!mcName) {
    throw new Error('查無此 UUID 對應的 Minecraft 帳號，請確認輸入正確');
  }

  const membersSheet = getSheet_(MEMBERS_SHEET);
  const data = membersSheet.getDataRange().getValues();
  let rowIndex = -1;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(discordId)) { rowIndex = i; break; }
  }

  // 擋掉「不同 Discord 帳號搶綁同一個 UUID」：這個 UUID 已經被別人的帳號在用，且狀態是 active
  for (let i = 1; i < data.length; i++) {
    const rowUuid = String(data[i][6] || '').toLowerCase();
    const rowStatus = data[i][3];
    const rowDiscordId = String(data[i][0]);
    if (rowUuid === uuid && rowStatus === 'active' && rowDiscordId !== String(discordId)) {
      throw new Error('這個 MC 帳號已經被其他 Discord 帳號綁定過了');
    }
  }

  const now = new Date();

  // 同一個帳號換綁不同 UUID：把舊的名字從白名單移除，避免一個會員佔用兩個名額
  if (rowIndex !== -1) {
    const oldMcName = data[rowIndex][2];
    const oldUuid = String(data[rowIndex][6] || '').toLowerCase();
    if (oldMcName && oldUuid !== uuid) {
      getSheet_(QUEUE_SHEET).appendRow([now, 'remove', oldMcName, 'pending', '', '換綁新 UUID，移除舊名額']);
    }
  }

  if (rowIndex === -1) {
    membersSheet.appendRow([discordId, '', mcName, 'active', now, now, uuid]);
  } else {
    membersSheet.getRange(rowIndex + 1, 3).setValue(mcName);
    membersSheet.getRange(rowIndex + 1, 4).setValue('active');
    membersSheet.getRange(rowIndex + 1, 6).setValue(now);
    membersSheet.getRange(rowIndex + 1, 7).setValue(uuid);
  }
  setRefreshToken_(discordId, refreshToken);

  getSheet_(QUEUE_SHEET).appendRow([now, 'add', mcName, 'pending', '', '']);
  return { ok: true, mcName: mcName };
}

// ------------------------------------------------------------
// 定時觸發（建議每小時跑一次）：
// 巡檢所有已登記成員，身分組被移除的自動送出白名單移除指令
// ------------------------------------------------------------
function checkAllMembers() {
  const sheet = getSheet_(MEMBERS_SHEET);
  const data = sheet.getDataRange().getValues();
  const now = new Date();
  // 由下往上跑，因為刪除列的時候，後面列的實際列號會往上遞補，
  // 由下往上處理才不會跑掉索引
  for (let i = data.length - 1; i >= 1; i--) {
    const discordId = data[i][0];
    const mcName = data[i][2];
    const status = data[i][3];
    if (status !== 'active' || !discordId) continue;
    if (isOverrideAllowed_(discordId)) {
      sheet.getRange(i + 1, 6).setValue(now); // 更新一下巡檢時間，代表有檢查過
      continue; // 永久放行名單裡的人，不做身分組驗證、不會被移除
    }
    const refreshToken = getRefreshToken_(discordId);

    let stillMember = false;
    if (refreshToken) {
      const refreshed = refreshUserAccessToken_(refreshToken);
      if (refreshed) {
        stillMember = checkMemberRoleWithUserToken_(refreshed.accessToken);
        if (refreshed.refreshToken !== refreshToken) {
          setRefreshToken_(discordId, refreshed.refreshToken);
        }
      } else {
        // refresh token 失效（例如使用者自己撤銷授權）：視同非會員，直接移除
        Logger.log('checkAllMembers: refresh token 失效，視同非會員移除 discordId=%s', discordId);
        stillMember = false;
      }
    } else {
      // 找不到 refresh token 的情況，退而求其次用 Bot Token（可能被擋）
      stillMember = checkMemberRoleWithBotToken_(discordId);
    }

    if (!stillMember) {
      getSheet_(QUEUE_SHEET).appendRow([now, 'remove', mcName, 'pending', '', '身分組已移除，自動退出']);
      sheet.deleteRow(i + 1); // 直接把這個會員從 Members 表刪掉，不是只改狀態
    } else {
      sheet.getRange(i + 1, 6).setValue(now);
    }
  }
}

// 手動執行一次即可（在 Apps Script 編輯器選這個函式按執行），
// 之後就會每小時自動跑 checkAllMembers()
function createHourlyTrigger() {
  ScriptApp.newTrigger('checkAllMembers').timeBased().everyHours(1).create();
}

// ------------------------------------------------------------
// 無條件放行：access_noers 分頁裡的名字（一列一個 MC 名稱，第一列可以當標題），
// 不管有沒有 Discord 身分組，都會被送進白名單，也不受 checkAllMembers 自動移除影響
// （因為這些名字根本不經過 Members 表這條路徑）
// ------------------------------------------------------------
function ensureAccessNoers() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const accessSheet = ss.getSheetByName(ACCESS_NOERS_SHEET);
  if (!accessSheet) {
    Logger.log('ensureAccessNoers: 找不到 %s 分頁，略過', ACCESS_NOERS_SHEET);
    return;
  }
  const names = accessSheet.getDataRange().getValues()
    .slice(1) // 跳過標題列
    .map((r) => String(r[0] || '').trim())
    .filter((n) => /^[A-Za-z0-9_]{3,16}$/.test(n));

  const statusSheet = ss.getSheetByName(STATUS_SHEET);
  const currentNames = statusSheet
    ? statusSheet.getDataRange().getValues().slice(1).map((r) => String(r[0] || '').toLowerCase())
    : [];

  const queueSheet = getSheet_(QUEUE_SHEET);
  const now = new Date();
  names.forEach((name) => {
    if (currentNames.indexOf(name.toLowerCase()) !== -1) return; // 已經在白名單裡了
    queueSheet.appendRow([now, 'add', name, 'pending', '', '無條件放行名單']);
  });
}

// 手動執行一次即可，之後每 10 分鐘自動跑 ensureAccessNoers()
function createAccessNoersTrigger() {
  ScriptApp.newTrigger('ensureAccessNoers').timeBased().everyMinutes(10).create();
}
