require('dotenv').config();
const fs = require('fs');
const { google } = require('googleapis');

const SPREADSHEET_ID = process.env.SPREADSHEET_ID;
const KEY_FILE = process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE;
const FIFO_PATH = process.env.MC_FIFO_PATH;
const WHITELIST_JSON_PATH = process.env.WHITELIST_JSON_PATH;

const QUEUE_SHEET = 'Queue';
const STATUS_SHEET = 'CurrentWhitelist';
const QUEUE_RANGE = `${QUEUE_SHEET}!A2:F`;

if (!SPREADSHEET_ID || !KEY_FILE || !FIFO_PATH || !WHITELIST_JSON_PATH) {
  console.error('請確認 .env 內 SPREADSHEET_ID / GOOGLE_SERVICE_ACCOUNT_KEY_FILE / MC_FIFO_PATH / WHITELIST_JSON_PATH 都已設定');
  process.exit(1);
}

const auth = new google.auth.GoogleAuth({
  keyFile: KEY_FILE,
  scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

function isValidUsername(name) {
  return typeof name === 'string' && /^[A-Za-z0-9_]{3,16}$/.test(name);
}

// 把指令寫進 FIFO，等同在主控台手動輸入該行指令並按 Enter
function sendCommand(cmd) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('寫入逾時，FIFO 可能沒有 reader（MC 伺服器沒在讀取）'));
    }, 3000);

    fs.open(FIFO_PATH, 'w', (err, fd) => {
      if (err) {
        clearTimeout(timer);
        if (!settled) { settled = true; reject(err); }
        return;
      }
      fs.write(fd, cmd + '\n', (writeErr) => {
        fs.close(fd, () => {
          clearTimeout(timer);
          if (settled) return;
          settled = true;
          writeErr ? reject(writeErr) : resolve();
        });
      });
    });
  });
}

async function updateRow(sheets, rowIndex, status, note) {
  const rowNum = rowIndex + 2; // +1 表頭列 +1 轉成 1-based
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `${QUEUE_SHEET}!D${rowNum}:F${rowNum}`,
    valueInputOption: 'RAW',
    requestBody: { values: [[status, new Date().toISOString(), note || '']] },
  });
}

async function processQueue(sheets) {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SPREADSHEET_ID,
    range: QUEUE_RANGE,
  });
  const rows = res.data.values || [];

  for (let i = 0; i < rows.length; i++) {
    const [, action, username, status] = rows[i];
    if (status !== 'pending') continue;

    if (!isValidUsername(username) || (action !== 'add' && action !== 'remove')) {
      await updateRow(sheets, i, 'error', '格式錯誤');
      continue;
    }
    try {
      await sendCommand(`whitelist ${action} ${username}`);
      await updateRow(sheets, i, 'done', '');
      console.log(`已處理: whitelist ${action} ${username}`);
    } catch (e) {
      await updateRow(sheets, i, 'error', e.message);
      console.error('處理失敗:', e.message);
    }
  }
}

async function syncCurrentWhitelist(sheets) {
  let names = [];
  try {
    const raw = fs.readFileSync(WHITELIST_JSON_PATH, 'utf8');
    const list = JSON.parse(raw);
    names = list.map((e) => e.name).filter(Boolean);
  } catch (e) {
    console.error('讀取 whitelist.json 失敗:', e.message);
    return;
  }
  const now = new Date().toISOString();
  const values = [['Username', 'UpdatedAt'], ...names.map((n) => [n, now])];

  await sheets.spreadsheets.values.clear({
    spreadsheetId: SPREADSHEET_ID,
    range: `${STATUS_SHEET}!A:B`,
  });
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `${STATUS_SHEET}!A1`,
    valueInputOption: 'RAW',
    requestBody: { values },
  });
}

async function main() {
  console.log('[' + new Date().toISOString() + '] poller 開始執行');
  const client = await auth.getClient();
  const sheets = google.sheets({ version: 'v4', auth: client });
  await processQueue(sheets);
  await syncCurrentWhitelist(sheets);
  console.log('[' + new Date().toISOString() + '] poller 執行完成');
}

main().catch((e) => {
  console.error('poller 執行失敗:', e);
  process.exit(1);
});
