#!/bin/bash
# ---------------------------------------------------------------------------
# 讓 Minecraft 伺服器的 java 行程接上一條 FIFO（named pipe）當作 stdin，
# 之後只要對這個 FIFO 寫入文字，效果就等同直接在主控台打指令按 Enter。
# ---------------------------------------------------------------------------

set -e

MC_DIR="/path/to/your/mc/server"                       # server.jar / paper.jar 所在資料夾，請自行修改
FIFO_PATH="/path/to/your/mc/mc-console.fifo"           # 要和 .env 的 MC_FIFO_PATH、start-mc.sh 的 FIFO_PATH 一致

echo "== 步驟 1：建立 FIFO =="
if [ ! -p "$FIFO_PATH" ]; then
  mkfifo "$FIFO_PATH"
  chmod 660 "$FIFO_PATH"
  echo "已建立 FIFO：$FIFO_PATH"
else
  echo "FIFO 已存在，略過"
fi

cat <<EOF2

== 步驟 2：用 tmux + start-mc.sh 啟動 MC ==

先確認 start-mc.sh 已經放在 $MC_DIR/start-mc.sh，並且已經 chmod +x。
start-mc.sh 內部用 "exec 3<>\"\$FIFO_PATH\"" 這種讀寫模式打開 FIFO，
避免單純用 "< \$FIFO_PATH" 重導向時，shell 會卡住等第一個 writer 才繼續執行的問題。

啟動指令：
    tmux new-session -d -s mc $MC_DIR/start-mc.sh

進入 / 離開畫面：
    tmux attach -t mc
    # 離開但不關閉伺服器：Ctrl+B 再按 D

== 步驟 3：測試 FIFO 有沒有接通 ==
    echo 'say test from fifo' > $FIFO_PATH
    tmux attach -t mc

如果主控台印出 "test from fifo"，代表接通成功，可以繼續部署 poller.js 了。

EOF2
