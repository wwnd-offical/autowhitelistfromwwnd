#!/bin/bash
# 請依你的實際環境修改這兩個變數
SERVER_DIR="/path/to/your/mc/server"           # paper.jar / server.jar 所在資料夾
FIFO_PATH="/path/to/your/mc/mc-console.fifo"   # 要跟 .env 的 MC_FIFO_PATH 一致

cd "$SERVER_DIR" || exit 1

# 用讀寫模式打開 FIFO 到 fd 3，避免單純用 < 重導向時卡住等待 writer
exec 3<>"$FIFO_PATH"

# 下面的記憶體大小（-Xms/-Xmx）跟 Aikar's flags 請依你主機規格調整
# 記憶體設定參考：https://docs.papermc.io/paper/aikars-flags
exec java -Xms4096M -Xmx4096M -XX:+AlwaysPreTouch -XX:+DisableExplicitGC \
  -XX:+ParallelRefProcEnabled -XX:+PerfDisableSharedMem -XX:+UnlockExperimentalVMOptions \
  -XX:+UseG1GC -XX:G1HeapRegionSize=8M -XX:G1HeapWastePercent=5 -XX:G1MaxNewSizePercent=40 \
  -XX:G1MixedGCCountTarget=4 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1NewSizePercent=30 \
  -XX:G1RSetUpdatingPauseTimePercent=5 -XX:G1ReservePercent=20 -XX:InitiatingHeapOccupancyPercent=15 \
  -XX:MaxGCPauseMillis=200 -XX:MaxTenuringThreshold=1 -XX:SurvivorRatio=32 \
  -Dusing.aikars.flags=https://mcflags.emc.gs -Daikars.new.flags=true \
  -jar paper.jar --nogui <&3
